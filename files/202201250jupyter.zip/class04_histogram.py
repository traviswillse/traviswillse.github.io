# -*- coding: utf-8 -*-
"""
"""

from collections import Counter
import numpy as np
from matplotlib import pyplot as plt

import urllib

url = "https://seattlecentral.edu/qelp/sets/039/s039.txt"

file = urllib.request.urlopen(url)

years, counts = np.loadtxt(file, delimiter='\t', usecols=(0, 1), unpack=True)

print(np.mean(counts))

histogram_data = Counter(counts)

#plt.bar([x + 0.5 for x in histogram_data.keys()],
#    histogram_data.values(),
#    1,
#    edgecolor = (0,0,0))

histogram_data = Counter(counts // 5 * 5)

plt.bar([x + 2.5 for x in histogram_data.keys()],
    histogram_data.values(), 5, edgecolor = (0,0,0))

plt.axis([0,50,0,30])
plt.title("Distribution of annual counts\nof earthquakes of magnitude >= 7.0")
plt.xlabel("annual counts")
plt.ylabel("frequencies")
plt.show()