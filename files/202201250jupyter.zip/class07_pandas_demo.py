# -*- coding: utf-8 -*-
"""
"""

import matplotlib as plt
import numpy as np
import pandas as pd

df = pd.read_csv('HW03_UNCG_Salaries.csv', sep=',',
                 dtype = {"Campus":         str,
                          "Name":           str,
                          "Department":     str,
                          "Position":       str,
                          "Title":          str,
                          "Hire_date":      int,
                          "Exempt":         str,
                          "FTE":          float,
                          "Employed":       int,
                          "Total_salary":   int,
                          "Service_yrs":    int})

df_fte = df[df['FTE'] == 1]

df_professors = df[df['Title'].str.contains("professor", case = False)]

department_list = sorted(list(set(df_professors['Department'].tolist())))
print(department_list, len(department_list))

df_fte_professors = df_fte[df_fte['Title'].str.contains("professor", case = False)]

department_color_dict = {'Dance':     'orange',
                         'Economics': 'blue',
                         'Management': 'green',
                         'Physics & Astronomy': 'red',
                         'History': 'purple'}

df_test = df_fte_professors[df_fte_professors['Department'].isin(department_color_dict.keys())]

print(df_test)

scatter = df_test.plot.scatter(
              x = 'Service_yrs',
              y = 'Total_salary',
              c = [department_color_dict[i] for i in df_test['Department']]
              )
                   
scatter.set_xlim(0,50)
scatter.set_ylim(0,300000)

#print(df.sort_values('Total_salary', ascending=False))

scatter.set_xlabel('service (y)')
scatter.set_ylabel('salary (USD)')
