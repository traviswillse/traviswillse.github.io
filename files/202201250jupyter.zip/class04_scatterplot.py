# -*- coding: utf-8 -*-
"""
@author: Travis Willse

data source for hawaii_emperor.tsv:
    Clague DA and Dalrymple BG (1989),
    Tectonics, geomorphology and origin of the Hawaiian-Emperor volcanic chain;
    in Winterer EL, Hussong DM and Decker RW (eds.),
    The Eastern Pacific Ocean and Hawaii;
    Geological Society of America, Boulder, Colorado;
    The Geology of North America, Volume N, pp. 188-217. 
"""

import csv

from matplotlib import pyplot as plt

volcanoes = []
ages      = []
distances = []

with open('hawaii_emperor.tsv') as f:
    volcano_reader = csv.reader(f, delimiter="\t")
    volcano_data_list = list(volcano_reader)[1:]

for row in volcano_data_list:
    volcanoes.append(row[1])
    ages.append(float(row[2]))
    distances.append(float(row[3]))

plt.scatter(ages, distances)

plt.title('Ages and travel distances of the volcanoes of the Hawaiʻi-Emperor chain')

plt.axis([70,0,0,5000])

plt.xlabel("age (My)")
plt.ylabel("distance (km)")

#for volcano, age, distance in zip(volcanoes, ages, distances):
#    plt.annotate('',
#                 xy=(age, distance),
#                 xytext=(5, -5),
#                 textcoords='offset points')

#plt.xlabel("age (My)")
#plt.ylabel("distance (km)")
